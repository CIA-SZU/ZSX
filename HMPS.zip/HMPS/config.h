#include "global.h"
#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <string>
#include <iostream>
#include "./lib/INIReader.h"
using namespace std;
int  verbose_level = 0;
std::string str_benchmark = "dMOP1";
int  nvar = 20,      //  the number of variables
nobj = 3;      //  the number of objectives
std::vector<double>  lowBound, uppBound;

bool pf_is_dynamic = false;
bool ps_is_dynamic = true;

bool print_fronts = false;
int max_gen = 390,
mygen = 1,
max_run = 1,
pops = 100;

int tau_t = 30,
n_t = 10;

std::string str_adaption = "RND";
double portion = 0.2;
double hyp_mut_rate = 0.5;
int det = 10;
//******** Parameters used in Kalman Filter for prediction *************************
double var_process = 0.04;
double var_measure = 0.01;

//******** Parameters in random number *********************************************
int seed = 177;
//*******  Parameters in MOEA/D ****************************************************
int niche = 20,
limit = 2,
unit = 13;
std::string strFunctionType = "_TCHE1",
strAlgorithmType = "_DE";
//******** Parameters in SBX *******************************************************
int etax = 20,
etam = 20;
double  realb = 0.9;

int num_centers = 10;
int read_config() {

	tau_t = 30;
	nvar = 20;
	n_t = 10;

	max_gen = 3600;
	ps_is_dynamic = true;
	int x2_min = 0;
	int x1_max = 1;
	int xn_max = 2;
	nobj = 3;
	int x2_max = 1;
	pf_is_dynamic = true;
	int x1_min = 0;
	int xn_min = -1;
	pops = 105;
	lowBound.push_back(x1_min);
	uppBound.push_back(x1_max);
	lowBound.push_back(x2_min);
	uppBound.push_back(x2_max);
	lowBound.resize(nvar, xn_min);
	uppBound.resize(nvar, xn_max);
	return 0;
}
