﻿#pragma once
#ifndef __EVOLUTION_H_
#define __EVOLUTION_H_

#include "global.h"
#include "direct.h"
#include <algorithm>
#include "./lib/recombination.h"
#include "./lib/common.h"
#include "dmoclass.h"
#include <stdlib.h>
#include <vector>
#include <cstring>
#include <random>
#include <iostream>
using namespace std;
class CMOEAD
{
public:

	CMOEAD();
	virtual ~CMOEAD();
	void init_uniformweight();               // initialize the weights for subproblems
	void init_neighbourhood();               // calculate the neighbourhood of each subproblem
	void init_population();                  // initialize the population
	void update_reference(CMOEADInd &ind);                 // update ideal point which is used in Tchebycheff or NBI method
	void update_problem(CMOEADInd &ind, int id, int type); // update current solutions in the neighbourhood
	void diffevolution();                                      // DE-based recombination
	void matingselection(vector<int> &list, int cid, int size, int type);  // select mating parents
																   
	void execute(int run);                      // execute MOEAD
	void save_pf(char *str);
	void save_ps(char *str);

	vector <CSUB>       population;
	vector <CSUB>       offspring;
	vector <int>        array;
	CMOEADInd           *ind_arr;
	vector<CMOEADInd>   pf;
	vector<CMOEADInd>   ps;
	int                popsize;

	//20170601  ****
	vector<double> pre_pop_center;   // population center at time step t-1
	vector<double> post_pop_center;  // population center at time step t

	//存储检测器目标均值 store the mean values in each objective dimension of all detectors at historical time steps
	vector <vector <double>>   save_detectObj_center; 
	
	//存储均值 store the population centers at historical time steps
	vector <vector <double>>   save_pop_center;       


	int  similarIndex = -1;      //记录相似环境的下标
	bool similar_flag = false;
	double threshold = 0.0001;   //判断相似环境的阈值

	int A_silimar = 0;
	int B_Dissimilar = 0;

	void first_to_reaction();  //react to the first change
	void change_reaction();  //react to the dissimilar change
	void change_reaction_toSimilar();  //react to the similar change
	void BubbleSort(double* pData, int count);

	// identify a change is similar one or dissimilar one
	void isSimilar(vector <vector <double>>  save_detectObj_center,vector <CMOEADInd> detect);
	
	bool calcul_diff(vector <double> detect_obj_c0 ,vector <double> detect_obj_c1);
	
	//calculate the mean values of all detectors at each objective dimension
	vector <double> calcul_detectObj_center(vector <CMOEADInd> detect); 


	void operator=(const CMOEAD &moea);
	//variabls used in dynamic MOP
	vector <CMOEADInd> detector;
	int n_change; // Record how many changes have happened
	bool isChange();

	//random initialization
	void reevaluate();
	void reinitialize();
	vector<int> change;
	//reinitialize ideal point
	void reinit_idealpoint();

};

CMOEAD::CMOEAD()
{
	ind_arr = new CMOEADInd[nobj];

	reinit_idealpoint();
}

void CMOEAD::reinit_idealpoint()
{
	// initialize ideal point
	for (int n = 0; n<nobj; n++)
	{
		idealpoint.push_back(1.0e+30);
		ind_arr[n].rnd_init();
		ind_arr[n].obj_eval();
	}
}
CMOEAD::~CMOEAD()
{
	idealpoint.clear();
	delete[] ind_arr;
}

void CMOEAD::init_population()
{

	for (int i = 0; i<population.size(); i++)
	{
		population[i].indiv.rnd_init();
		population[i].indiv.obj_eval();

		update_reference(population[i].indiv);

	}

	//initialize the detector
	for (int i = 0; i<det; i++)
	{
		CMOEADInd temp;
		detector.push_back(temp);
		detector[i].rnd_init();
		detector[i].obj_eval();
	}
}

void CMOEAD::operator=(const CMOEAD &alg)
{

	population = alg.population;
	ind_arr = alg.ind_arr;
	offspring = alg.offspring;
	popsize = alg.popsize;
}

// creates the weight vectors with uniform distribution
void CMOEAD::init_uniformweight()
{
	if (nobj == 2)
	{
		for (int n = 0; n<pops; n++)
		{
			CSUB sub;
			double a = 1.0*n / (pops - 1);
			sub.namda.push_back(a);
			sub.namda.push_back(1 - a);

			//load weight vectors from file
			//sub.namda.push_back(ws[n].y_obj[0]);
			//sub.namda.push_back(ws[n].y_obj[1]);

			population.push_back(sub);
		}
		popsize = pops;
	}
	else
	{
		for (int i = 0; i <= unit; i++)
		{
			for (int j = 0; j <= unit; j++)
			{
				if (i + j <= unit)
				{
					CSUB sub;
					sub.array.push_back(i);
					sub.array.push_back(j);
					sub.array.push_back(unit - i - j);
					for (int k = 0; k<sub.array.size(); k++)
						sub.namda.push_back(1.0*sub.array[k] / unit);
					population.push_back(sub);
				}
			}
		}

		popsize = population.size();
		pops = popsize;
	}
}

void CMOEAD::init_neighbourhood()
{
	double *x = new double[population.size()];
	int *idx = new int[population.size()];
	for (int i = 0; i<population.size(); i++)
	{
		// calculate the distances based on weight vectors
		for (int j = 0; j<population.size(); j++)
		{
			x[j] = dist_vector(population[i].namda, population[j].namda);
			idx[j] = j;
		}

		// find 'niche' nearest neighboring subproblems
		minfastsort(x, idx, population.size(), niche);
		for (int k = 0; k<niche; k++)
		{
			population[i].table.push_back(idx[k]);
		}

	}
	delete[] x;
	delete[] idx;
}

void CMOEAD::update_problem(CMOEADInd &indiv, int id, int type)
{
	// indiv: child solution
	// id:   the id of current subproblem
	// type: update solutions in - neighborhood (1) or whole population (otherwise)
	int size, time = 0;
	if (type == 1) size = population[id].table.size();
	else size = population.size();
	int *perm = new int[size];
	random_permutation(perm, size);
	for (int i = 0; i<size; i++)
	{
		int k;
		if (type == 1) k = population[id].table[perm[i]];
		else k = perm[i];

		// calculate the values of objective function regarding the current subproblem
		double f1, f2;
		f1 = fitnessfunction(population[k].indiv.y_obj, population[k].namda, ind_arr);
		f2 = fitnessfunction(indiv.y_obj, population[k].namda, ind_arr);

		if (f2<f1)
		{
			population[k].indiv = indiv;
			time++;
		}
		// the maximal number of solutions updated is not allowed to exceed 'limit'
		if (time >= limit)
		{
			return;
		}
	}
	delete[] perm;
}

void CMOEAD::update_reference(CMOEADInd &ind)
{
	//ind: child solution
	for (int n = 0; n<nobj; n++)
	{
		if (ind.y_obj[n]<idealpoint[n])
		{
			idealpoint[n] = ind.y_obj[n];
			ind_arr[n] = ind;
		}
	}
}

void CMOEAD::matingselection(vector<int> &list, int cid, int size, int type) {
	// list : the set of the indexes of selected mating parents
	// cid  : the id of current subproblem
	// size : the number of selected mating parents
	// type : 1 - neighborhood; otherwise - whole population
	int ss = population[cid].table.size(), r, p;
	while (list.size()<size)
	{
		if (type == 1) {
			r = int(ss*rnd_uni(&rnd_uni_init));
			p = population[cid].table[r];
		}
		else
			p = int(population.size()*rnd_uni(&rnd_uni_init));

		bool flag = true;
		for (int i = 0; i<list.size(); i++)
		{
			if (list[i] == p) // p is in the list
			{
				flag = false;
				break;
			}
		}
		if (flag) list.push_back(p);
	}
}

void CMOEAD::diffevolution()
{
	pops = population.size();
	int *perm = new int[pops];
	random_permutation(perm, pops);

	for (int i = 0; i<pops; i++)
	{
		int n = perm[i];
		// or int n = i;
		int type;
		double rnd = rnd_uni(&rnd_uni_init);

		// mating selection based on probability
		if (rnd<realb) type = 1; // neighborhood
		else type = 2; // whole population

					   // select the indexes of mating parents
		vector<int> p;
		matingselection(p, n, 2, type); // neighborhood selection

		CMOEADInd child;    // produce a child solution
		diff_evo_xover2(population[n].indiv, population[p[0]].indiv, population[p[1]].indiv, child);

		// apply polynomial mutation
		realmutation(child, 1.0 / nvar);
		// evaluate the child solution
		child.obj_eval();
		// update the reference points and other solutions in the neighborhood or the whole population
		update_reference(child);
		update_problem(child, n, type);
		p.clear(); nfes++;
	}
	delete[] perm;
}


void CMOEAD::execute(int run)
{
	seed = (seed + 23) % 1377;
	rnd_uni_init = -(long)seed;
	// load the representative Pareto-optimal solutions

	int cur_id;

	// initialization 
	int gen = 1;
	tau = 1;
	n_change = 0;
	nfes = 0;
	init_uniformweight();
	init_neighbourhood();
	init_population();

	while (gen <= max_gen)
	{   
		tau = gen;
		//using for dMOP3  refer as SGEA
		double T_t = 0.0;
		T_t = 1.0 / n_t*(floor(1.0*tau / tau_t));
		if ((T_t > 0) && (gen%tau_t == 0))
		if (str_benchmark == "dMOP3")
		{
			Parar = (int)nvar*rnd_uni(&rnd_uni_init);
		}
		/***/
	
		char filename[1024];
		char filename1[1024];
		char parName1[100];
		char parName[100];
		char    strTestInstance[256];
		// set path for output
		string path = "E:\\experiment\\HMPS";
		_mkdir(path.c_str());

		strcpy_s(strTestInstance, str_benchmark.c_str());
		sprintf_s(parName1, path.append("\\%s").c_str(), strTestInstance);
		if (_mkdir(parName1))
		//	cout << "this file has already existed." << endl;
		sprintf_s(parName, "%s\\run_%d", parName1, run);
		if (_mkdir(parName))
		//	cout << "this file has already existed." << endl;
		sprintf_s(filename, "%s\\pop_gen_%i.txt", parName, gen);

		if (gen%30==0)
		{
		  save_pf(filename);
		}

		//sprintf_s(filename1, "%s\\ps%i.txt", parName, gen);
		//save_ps(filename1);
		//save_ps(filename);

		//dynamic MOP
		if (isChange())
		{
			cout << "a change occurred at generation " << gen << endl;
		//	cout << "相似变化次数" << A_silimar << endl;
		//	cout << "不相似变化次数" << B_Dissimilar << endl;
			change.push_back(1);
		//	cout << n_change << endl;
			n_change++;
		//	cout << n_change << endl;

			if (n_change == 1)
			{
				//save the mean objective values of all detectors at first time step
				vector <double> detectObj_center = calcul_detectObj_center(detector);
				save_detectObj_center.push_back( detectObj_center );
				//calculate the population center at time t
				post_pop_center.clear();
				for (int n = 0; n < nvar; n++)
				{
					double sum = 0.0;
					for (int i = 0; i < population.size(); i++)
					{
						sum += population[i].indiv.x_var[n];
					}
					post_pop_center.push_back(sum / population.size());
				}
				//react to the first change
				first_to_reaction();
			}
			else
			{
				   //update the pre_pop_center
				   pre_pop_center = post_pop_center;
				   post_pop_center.clear();

				   //calculate the population center at time t
				   for (int n = 0; n < nvar; n++)
				   {
					   double sum = 0.0;
					   for (int i = 0; i < population.size(); i++)
					   {
						   sum += population[i].indiv.x_var[n];
					   }
					   post_pop_center.push_back(sum / population.size());
				   }
					//maintain_memory
				    if (similarIndex != -1 && similar_flag == true)   save_pop_center[similarIndex] = post_pop_center;
				    else save_pop_center.push_back(post_pop_center);
		
					isSimilar(save_detectObj_center, detector);
					if (similar_flag) 
					{
						change_reaction_toSimilar(); //react to similar change
						vector <double> detectObj_center = calcul_detectObj_center(detector);
						//更新存档
						save_detectObj_center[similarIndex] = detectObj_center;

					}else{

						if(save_detectObj_center.size() > memory_size)
						{
							save_detectObj_center.erase(save_detectObj_center.begin());
							save_pop_center.erase(save_pop_center.begin());
							change_reaction();
						}
						else{
						   vector <double> detectObj_center = calcul_detectObj_center(detector);
						   save_detectObj_center.push_back(detectObj_center);
						   change_reaction();
						}
					}
			} 

			for (int i = 0; i < population.size(); i++)
			{
				population[i].indiv.obj_eval();
				reinit_idealpoint();
				update_reference(population[i].indiv);
				update_problem(population[i].indiv, i, 1);
			}
				
		}else {
			diffevolution();
			change.push_back(0);
		}
		gen++;
	}
	cout << " Outcome of the " << run << "th run of " << str_benchmark << ", ";
	//cout << "相似变化次数" << A_silimar<< endl;
	//cout << "不相似变化次数" << B_Dissimilar << endl;
	population.clear();
	pf.clear();
	ps.clear();
}

bool CMOEAD::isChange()
{
	int count = 0;
	vector<double> temp;
	for (int i = 0; i < det; i++)
	{
		temp = detector[i].y_obj;
		detector[i].obj_eval();
		if (temp != detector[i].y_obj)
			count++;
	}
	temp.clear();
	if (count > 0) return true;
	return false;

}

void CMOEAD::reevaluate()
{
	for (int i = 0; i < population.size(); i++)
	{
		population[i].indiv.obj_eval();
		reinit_idealpoint();
		update_reference(population[i].indiv);
		update_problem(population[i].indiv, i, 1);
	}
}

void CMOEAD::reinitialize()
{
	vector <int> index;
	int count = 0;

	for (int i = 0; i < population.size(); i++)
		index.push_back(0);

	while (count < portion*population.size())
	{
		int i = floor(population.size() * rnd_uni(&rnd_uni_init));
		if (index[i] == 0)
		{
			index[i] = 1;
			count++;
		}
	}

	for (int i = 0; i < population.size(); i++)
	{
		if (index[i] == 1)
			population[i].indiv.rnd_init();
	}
	index.clear();
}

void CMOEAD::save_pf(char *saveFilename)
{
	std::fstream fout;
	fout.open(saveFilename, std::ios::out);
	for (int n = 0; n<popsize; n++)
	{
		for (int k = 0; k<nobj; k++)
		{
			fout << population[n].indiv.y_obj[k];
			k < nobj - 1 ? fout << "," : fout << endl;
		}
	}

	fout.close();
}

void CMOEAD::save_ps(char *saveFilename)
{
	std::fstream fout;
	fout.open(saveFilename, std::ios::out);
	for (int n = 0; n<popsize; n++)
	{
		for (int k = 0; k<nvar; k++)
		{
			fout << population[n].indiv.x_var[k];
			k < nvar - 1 ? fout << "	" : fout << endl;
		}
	}
	fout.close();
}


//变化响应
void CMOEAD::change_reaction()
{
	B_Dissimilar += 1;
	
	double stepsize = dist_vector(pre_pop_center,post_pop_center);
	double stddev = stepsize / nvar;

	//cout << stddev << endl;
	//定义一个数组
	double *sortpop = (double *)malloc(sizeof(double) * population.size());
	//计算适应值
	for (int i = 0; i < population.size(); i++)
	{
		population[i].indiv.fitness = fitnessfunction(population[i].indiv.y_obj, population[i].namda, ind_arr);
		sortpop[i] = population[i].indiv.fitness;
	}	

	//根据个体适应值排序
	BubbleSort(sortpop, population.size());
	int flag1 = population.size()*0.5;

	//适应值最好的一半个体采用预测策略
	for (int i = 0; i < population.size(); i++)
	{
		if(population[i].indiv.fitness < sortpop[flag1])
		{
			for (int n = 0; n < nvar; n++)
			{ 
				population[i].indiv.x_var[n] += post_pop_center[n] - pre_pop_center[n] + rnd_gaussian(&rnd_uni_init,0,stddev);
				//上下边界修复
				if (population[i].indiv.x_var[n] < lowBound[n]) population[i].indiv.x_var[n] = lowBound[n];
				if (population[i].indiv.x_var[n] > uppBound[n]) population[i].indiv.x_var[n] = uppBound[n];
			}	
		}
		else
		{
			if (rnd_uni(&rnd_uni_init) < 0.5)   population[i].indiv = population[i].indiv;
			else  population[i].indiv.rnd_init();
		}
	} 
}

void CMOEAD::change_reaction_toSimilar()
{
	A_silimar += 1;
	cout << " change is similar! " << endl;

	//定义一个数组
	double *sortpop = (double *)malloc(sizeof(double) * population.size());
	//计算适应值
	for (int i = 0; i < population.size(); i++)
	{
		population[i].indiv.fitness = fitnessfunction(population[i].indiv.y_obj, population[i].namda, ind_arr);
		sortpop[i] = population[i].indiv.fitness;
	}

	//根据个体适应值排序
	BubbleSort(sortpop, population.size());
	int flag1 = population.size()*0.5;
	for (int i = 0; i < population.size(); i++)
	{
		if(population[i].indiv.fitness < sortpop[flag1])
		{
			for (int n = 0; n < nvar; n++)
			{
				population[i].indiv.x_var[n] = population[i].indiv.x_var[n] - post_pop_center[n] + save_pop_center[similarIndex][n];
				//上下边界修复
				if (population[i].indiv.x_var[n] < lowBound[n]) population[i].indiv.x_var[n] = lowBound[n];
				if (population[i].indiv.x_var[n] > uppBound[n]) population[i].indiv.x_var[n] = uppBound[n];
			}
		}
		else
		{
			if (rnd_uni(&rnd_uni_init) < 0.5)   population[i].indiv = population[i].indiv;
			else  population[i].indiv.rnd_init();
		}
	
     } 
}

void CMOEAD::first_to_reaction()
{
	//定义一个数组
	double *sortpop = (double *)malloc(sizeof(double) * population.size());
	//计算适应值
	for (int i = 0; i < population.size(); i++)
	{
		population[i].indiv.fitness = fitnessfunction(population[i].indiv.y_obj,population[i].namda,ind_arr);
		sortpop[i] = population[i].indiv.fitness;
	}
	//根据个体适应值排序
	BubbleSort(sortpop, population.size());
	int flag1 = population.size() * 0.5;
	
	//step1 保留适应值最好的50%个个体  maintain a good distribution
	for (int i = 0; i < population.size(); i++)
	{
		if(population[i].indiv.fitness < sortpop[flag1])
		{
			population[i].indiv = population[i].indiv;
		}
		else  population[i].indiv.rnd_init();	
	}
	B_Dissimilar += 1;
}

void CMOEAD::BubbleSort(double* pData, int count)
{
	double temp;
	for (int i = 1; i < count; i++)
	{
		for (int j = count - 1; j >= i; j--)
		{
			if (pData[j] < pData[j - 1])
			{
				temp = pData[j - 1];
				pData[j - 1] = pData[j];
				pData[j] = temp;
			}
		}
	}
}


void CMOEAD::isSimilar(vector <vector <double>>  save_detectObj_center,vector <CMOEADInd> detect)
{ 
    vector <double>  detectObj_center = calcul_detectObj_center(detect);
	for (int i = 0; i < save_detectObj_center.size(); i++)
	{
		if(calcul_diff(save_detectObj_center[i], detectObj_center))
		{
			similarIndex = i;
			similar_flag = true;
			break;
		}else{
			similarIndex = -1;
			similar_flag = false;
		}
	}	 
}

bool CMOEAD::calcul_diff(vector <double> detect_obj_c0, vector <double> detect_obj_c1) 
{
	int count = 0;
	for (int i = 0; i < detect_obj_c0.size();i++)
	{
		if(abs(detect_obj_c0[i] - detect_obj_c1[i])<threshold)
		{
			count++;
		}
	}
	if (count == detect_obj_c0.size()) return true;
	else return false;
}

vector <double> CMOEAD::calcul_detectObj_center(vector <CMOEADInd> detect)
{
	vector <double>  detector_Obj_mean;   //目标空间,每一维目标的均值
	for (int n = 0; n < nobj; n++)
	{
		double sum = 0;
		for (int i = 0; i < detect.size(); i++)
		{
			sum += detect[i].y_obj[n];
		}
		sum /= detect.size();
		detector_Obj_mean.push_back(sum);
	}
	return detector_Obj_mean;
}


#endif