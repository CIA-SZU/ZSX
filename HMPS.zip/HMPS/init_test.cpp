#pragma once
#include "config.h"
#include "moeadclass.h"
#include "global.h"

//#include <unistd.h>
#include <time.h>
#include <iostream>
#include <string>
using namespace std;
int main(int argc, char* argv[]) {

	str_benchmark = "F8";
	str_adaption = "HMPS";
	max_run = 5;

	read_config();   //�����ļ���ʵ�����������
	clock_t now, later;
	double passed = 0.0; //����ʱ��
						 //char timeName[30];
						 //FILE *timeFile;

						 //sprintf(timeName, "%s_times.txt", str_benchmark);
						 //timeFile = fopen(timeName, "w");
	string timeFile = str_benchmark + "_times.txt";
	char parName1[1024];
	sprintf(parName1, timeFile.c_str());
	std::fstream fout;
	fout.open(parName1, std::ios::out);
	for (int run = 1; run <= max_run; run++)
	{
		if (str_adaption == "DNSGAIIA" || str_adaption == "DNSGAIIB") {
			//CNSGA2 NSGA2;
			//NSGA2.execute(run);
		}
		else {
			CMOEAD  MOEAD;
			/*if (run == 1)
				now = clock();
			later = clock();
			passed = (later - now) / (double)CLOCKS_PER_SEC;
			cout << passed << std::endl;*/
			MOEAD.execute(run);

			/*if (run == 1) {
				later = clock();
				passed = (later - now) / (double)CLOCKS_PER_SEC;
				//fprintf(timeFile, "%lf\n", passed);
				fout << passed << std::endl;
			}*/
		}
	}
	fout.close();
	return 0;
}
