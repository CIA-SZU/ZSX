#ifndef __INDIVIDUAL_H_
#define __INDIVIDUAL_H_

#include "global.h"
#include <random>
#include <iostream>
#include "./benchmark_dmop2.h"

class CMOEADInd {
public:
	CMOEADInd();
	virtual ~CMOEADInd();
	//store xvar yvar;
	vector <double> x_var;
	vector <double> y_obj;
	void   rnd_init();
	void   zero_init();
	void   obj_eval();

	bool   operator<(const CMOEADInd &ind2);
	bool   operator<<(const CMOEADInd &ind2);
	bool   operator==(const CMOEADInd &ind2);
	void   operator=(const CMOEADInd &ind2);
	void show_objective();
	void show_variable();
	int compare(const CMOEADInd &ind2);
	
	double fitness;   //������Ӧֵ
	int fitness_rank;
	int   rank;
	

};

CMOEADInd::CMOEADInd()
{
	for (int i = 0; i<nvar; i++)
		x_var.push_back(0.0);
	for (int n = 0; n<nobj; n++)
		y_obj.push_back(0.0);
		rank = 0;
}

CMOEADInd::~CMOEADInd()
{

}

void CMOEADInd::rnd_init()
{
	random_device rd;
	mt19937 gen(rd());
	for (int n = 0; n < nvar; n++)
	{
		std::uniform_real_distribution<double> distribution(lowBound[n], uppBound[n]);
		x_var[n] = distribution(gen);
	}
}

void CMOEADInd::zero_init()
{
	for (int n = 0; n<nvar; n++)
		x_var[n] = 0;
}


void CMOEADInd::obj_eval()
{
	//or objective(x_var,y_obj);	
	dmoptest(x_var, y_obj);
}

void CMOEADInd::show_objective()
{
	for (int n = 0; n<nobj; n++)
		printf("%f ", y_obj[n]);
	printf("\n");
}

void CMOEADInd::show_variable()
{
	for (int n = 0; n<nvar; n++)
		printf("%f ", x_var[n]);
	printf("\n");
}

void CMOEADInd::operator=(const CMOEADInd &ind2)
{
	x_var = ind2.x_var;
	y_obj = ind2.y_obj;
	rank = ind2.rank;
}

bool CMOEADInd::operator<(const CMOEADInd &ind2)
{
	bool dominated = true;
	for (int n = 0; n<nobj; n++)
	{
		if (ind2.y_obj[n]<y_obj[n]) return false;
	}
	if (ind2.y_obj == y_obj) return false;
	return dominated;
}


bool CMOEADInd::operator<<(const CMOEADInd &ind2)
{
	bool dominated = true;
	for (int n = 0; n<nobj; n++)
	{
		if (ind2.y_obj[n]<y_obj[n] - 0.0001) return false;
	}
	if (ind2.y_obj == y_obj) return false;
	return dominated;
}

bool CMOEADInd::operator==(const CMOEADInd &ind2)
{
	if (ind2.y_obj == y_obj) return true;
	else return false;
}


int CMOEADInd::compare(const CMOEADInd &ind2)
{
	// 2: equals ind2
	// 1: dominated by ind2;
	// 0: mutually nondominated;
	//-1: dominate ind2
	int less = 0, more = 0;
	for (int n = 0; n<nobj; n++)
	{
		if (fabs(ind2.y_obj[n] - y_obj[n])<1.0E-300) continue;
		if (ind2.y_obj[n]<y_obj[n]) more++;
		if (ind2.y_obj[n]>y_obj[n]) less++;
		if (more>0 && less>0) return 0;
	}
	if (more>0 && less == 0) return 1;
	if (less>0 && more == 0) return -1;
	if (less == 0 && more == 0) return 2;
}

class CSUB
{
public:
	CSUB();
	virtual ~CSUB();

	void show();

	CMOEADInd       indiv;     // best solution
	CMOEADInd       indiv_p;     // solution used for prediction 
	vector <int>    array;     // lattice point in a simplex
	vector <double> namda;     // weight vector
	vector <int>    table;     // neighbourhood table

	double          density, fitness;
	void  operator=(const CSUB &sub2);

	vector<CMOEADInd> preValues;
};

CSUB::CSUB()
{
}

CSUB::~CSUB() {
}

void CSUB::show()
{
	for (int n = 0; n<namda.size(); n++) {
		printf("%f ", namda[n]);
	}
	printf("\n");
}

void CSUB::operator=(const CSUB &sub2) {
	indiv = sub2.indiv;
	indiv_p = sub2.indiv_p;
	array = sub2.array;
	table = sub2.table;
	namda = sub2.namda;
}

#endif
