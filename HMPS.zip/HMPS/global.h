#pragma once
#ifndef __GLOBAL_H_
#define __GLOBAL_H_
#define pi 3.141592653589793
#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include "./lib/random.h"

//******** Test settings ********
extern bool print_fronts;
extern int verbose_level;

//******** Common parameters in MOEAs **********************************************
extern int max_gen,    //  the maximal number of generations
max_run,      //  the maximal number of runs
pops;    //  the population size
int nfes;             //  the number of function evluations
int tau;		// record the state of the current dynamic objective function 

				//******** Parameters in dynamic test instance *************************************
extern int tau_t,				// the number of generation for which t remains fixed
n_t;				// the number of distinct steps in t

					//******** Variables used in dynamic multi-objective optimization algorithm ********
extern int		det;		// number of detectors
extern std::string  str_adaption; // the predition method used
extern double	portion;		// percentage of new random initialized individual 
extern double hyp_mut_rate;

extern int recomb_operator; //DE or SBX for recombination operator
							//******** Benchmark Parameters*****************************************************
extern std::string str_benchmark;
extern int  nvar,      //  the number of variables
nobj;      //  the number of objectives

extern std::vector<double>  lowBound, uppBound;
extern bool pf_is_dynamic;
extern bool ps_is_dynamic;
//**** kalman order ***/
int kalman_order = 3;
//******** Parameters in random number *********************************************
extern int     seed;
long rnd_uni_init;

//*******  Parameters in MOEA/D ****************************************************
extern int	   niche, limit, unit;
double scale[100];
std::vector <double> idealpoint;
extern std::string strFunctionType, strAlgorithmType;

//******** Parameters in SBX *******************************************************
extern int     etax, etam;
extern double  realx, realm,    // probability in SBX crossover and polynomial mutation
realb;     // probability of selecting mating parents from neighborhood
extern int     gID;

//******** Parameters for SVR ******************************************************
int trainSize = 10;

//******Hausdorff calculation ******************************************************
int p_hausdorff = 2;

double wtc0=0.0, wtc1=0.0;

//******parameter for memory ******************************************************
int memory_size = 50;   
int   Parar = 0;              // unchanged index within a time window, 0 at the beginning  used for dMOP3(a random diversity variable)
#endif