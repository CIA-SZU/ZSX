#ifndef __DMOP_H_
#define __DMOP_H_

#include "global.h"
#include "./lib/mylib.h"
//dynamic MOP test problems
void dmoptest(vector<double> &x_var, vector <double> &y_obj)
{
	//Implement DMOP test functions and HE test functions
	//FDA1: Type I, convex POF
	//n = 20, tau_t = 5 and n_t = 10
	//x_var[0] in [0,1]
	//x_var[1 - (nvar -1)] in [-1,1]
	if (str_benchmark == "FDA1")
	{
		double t;
		double G_t;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		G_t = sin(0.5 * pi * t);

		double g = 0;
		for (int n = 1; n < nvar; n++)
			g += (x_var[n] - G_t) * (x_var[n] - G_t);
		g = g + 1;

		y_obj[0] = x_var[0];
		y_obj[1] = g * (1 - sqrt(y_obj[0] / g));
	}

	//FDA2: Type II, convex to nonconvex POFs
	//Original version
	//n = 31, tau_t = 5, n_t = 10
	//x_var[0] in [0,1]
	//x_II and x_III in [-1,1]
	if (str_benchmark == "FDA2")
	{
		double t;
		double H_t;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		H_t = 1.25 + 0.75 * sin(0.5*pi*t);

		double g = 0, h = 0;
		for (int n = 1; n < nvar; n++)
		{
			//x_II: n is odd
			//x_III: n is even
			if (n % 2 == 1)
				g += x_var[n] * x_var[n];
			else
				h += (x_var[n] - H_t / 4) * (x_var[n] - H_t / 4);
		}
		g = 1 + g;
		h = H_t + h;

		y_obj[0] = x_var[0];
		y_obj[1] = g * (1 - pow(y_obj[0] / g, h));
	}
	
	//FDA2 - > Following the definition of dMOP1
	/*if (str_benchmark == "FDA2")
	{
	double t;
	double H_t;
	t = 1.0/n_t*floor(1.0*tau/tau_t);
	H_t = 1.25 + 0.75 * sin(0.5*pi*t);

	double g = 0;
	for (int n = 1; n < nvar; n++)
	{
	g += x_var[n] * x_var[n];
	}
	g = 1 + g;

	y_obj[0] = x_var[0];
	y_obj[1] = g * (1 - pow(y_obj[0] / g, H_t));
	}*/

	//FDA3: Type II, convex POFs
	//n = 30, tau_t = 5, n_t = 10
	//x_I in [0,1] and x_II in [-1,1]
	//|x_I| = 5 and |x_II| = 25
	if (str_benchmark == "FDA3")
	{
		double t;
		double F_t, G_t;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		F_t = pow(10, 2 * sin(0.5 * pi * t));
		G_t = abs(sin(0.5 * pi * t));

		double g = 0;
		//for (int n = 5; n < nvar; n++)
		for (int n = 1; n < nvar; n++)
			g += (x_var[n] - G_t) * (x_var[n] - G_t);
		g = 1 + G_t + g;

		double f = 0;
		//for (int n = 0; n < 5; n++)
		for (int n = 0; n < 1; n++)
			f += pow(x_var[n], F_t);
		y_obj[0] = f;
		y_obj[1] = g * (1 - sqrt(y_obj[0] / g));
	}

	//FDA4: Type I, nonconvex POFs
	//n = M + 9, tau_t = 5, n_t = 10
	//x in [0, 1]
	//|x_II| = 10
	if (str_benchmark == "FDA4")
	{
		double t;
		double G_t;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		G_t = abs(sin(0.5 * pi * t));

		double g = 0;
		for (int n = nobj - 1; n < nvar; n++)
			g += (x_var[n] - G_t) * (x_var[n] - G_t);

		//for f_1
		y_obj[0] = 1;
		for (int n = 0; n < nobj - 1; n++)
			y_obj[0] *= cos(0.5 * pi * x_var[n]);

		//for f_2 to f_M-1
		/*for (int n = 1; n < nobj - 1; n++)
		{
		y_obj[n] = 1;
		for (int i = 0; i < nobj - n - 1; i++)
		y_obj[n] *= cos(0.5 * pi * x_var[i]);
		y_obj[n] *= sin(0.5 * pi * x_var[nobj - n - 1]);
		}*/
		y_obj[1] = 1;
		y_obj[1] *= cos(0.5*pi*x_var[1]);
		y_obj[1] *= sin(0.5*pi*x_var[0]);

		//for f_M  x2
		y_obj[nobj - 1] = sin(0.5 * pi * x_var[1]);

		//multiply every objective by (1+g)
		for (int n = 0; n < nobj; n++)
			y_obj[n] *= (1 + g);
	}

	//FDA5: Type II, nonconvex POFs
	//n = M + 9, tau_t = 5, n_t = 10
	//x in [0, 1]
	//|x_II| = 10
	if (str_benchmark == "FDA5")
	{
		double t;
		double G_t, F_t;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		G_t = abs(sin(0.5 * pi * t));
		F_t = 1 + 100 * pow(sin(0.5 * pi * t), 4);

		double g = 0;
		for (int n = nobj - 1; n < nvar; n++)
			g += (x_var[n] - G_t) * (x_var[n] - G_t);
		g += G_t;

		//for f_1
		y_obj[0] = 1;
		for (int n = 0; n < nobj - 1; n++)
			y_obj[0] *= cos(0.5 * pi * pow(x_var[n], F_t));

		//for f_2 to f_M-1
		for (int n = 1; n < nobj - 1; n++)
		{
			y_obj[n] = 1;
			for (int i = 0; i < nobj - n - 1; i++)
				y_obj[n] *= cos(0.5 * pi * pow(x_var[i], F_t));
			y_obj[n] *= sin(0.5 * pi * pow(x_var[nobj - n - 1], F_t));
		}

		//for f_M
		y_obj[nobj - 1] = sin(0.5 * pi * pow(x_var[0], F_t));

		//multiply every objective by (1+g)
		for (int n = 0; n < nobj; n++)
			y_obj[n] *= (1 + g);
	}

	if (str_benchmark == "FDA5iso")
	{
		double t;
		double G_t, F_t;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		G_t = abs(sin(0.5 * pi * t));
		F_t = 1 + 100 * pow(sin(0.5 * pi * t), 4);

		double g = 0;
		for (int n = nobj - 1; n < nvar; n++)
			g += (x_var[n] - G_t) * (x_var[n] - G_t);
		g += G_t;
	}

	//FDA6: Type II, convex to nonconvex POFs
	//Original version
	//n = 31, tau_t = 5, n_t = 10
	//x_var[0] in [0,1]
	//x_II and x_III in [-1,1]
	/*if (str_benchmark == "FDA6")
	{
	double t;
	double H_t, G_t;
	t = 1.0/n_t*floor(1.0*tau/tau_t);
	G_t = sin(0.5 * pi * t);
	H_t = 0.2 + 4.8*G_t*G_t;

	double g = 0, h = 0;
	for (int n = 1; n < nvar; n++)
	{
	//x_II: n is odd
	//x_III: n is even
	if (n % 2 == 1)
	g += x_var[n] * x_var[n];
	else
	g += (x_var[n] + 1) * (x_var[n] + 1);
	}
	g = 1 + g;

	y_obj[0] = x_var[0];
	h = 1 - pow(y_obj[0] / g, H_t);
	y_obj[1] = g * h;
	}*/

	//ZJZ(FDA6): Type II, convex and nonconvex POF
	//n = 20, tau_t = 5 and n_t = 10
	//x_var[0] in [0,1]
	//x_var[1 - (nvar -1)] in [-1,2]
	if (str_benchmark == "ZJZ")
	{
		double t;
		double G_t, H_t;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		G_t = sin(0.5 * pi * t);
		H_t = 1.5 + G_t;

		double g = 0;
		for (int n = 1; n < nvar; n++)
			g += (x_var[n] + G_t - pow(x_var[0], H_t)) * (x_var[n] + G_t - pow(x_var[0], H_t));
		g = g + 1;

		y_obj[0] = x_var[0];
		//y_obj[1] = g * (1 - pow(y_obj[0]/g, H_t));
		y_obj[1] = 1 - pow(y_obj[0] / g, H_t);

	}
	//dMOP functions suggested by Goh and Tan
	if (str_benchmark == "dMOP1")
	{
		double t, H_t;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		H_t = 1.25 + 0.75 * sin(0.5 * pi * t);

		double g = 0;
		for (int n = 1; n<nvar; n++)
			g += x_var[n] * x_var[n];
		g = 1 + 9 * g;

		y_obj[0] = x_var[0];
		y_obj[1] = g * (1 - pow(y_obj[0] / g, H_t));
	}

	if (str_benchmark == "dMOP2")
	{
		double t;
		double G_t, H_t;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		G_t = sin(0.5 * pi * t);
		H_t = 1.25 + 0.75 * sin(0.5 * pi * t);

		double g = 1;
		for (int n = 1; n<nvar; n++)
			g += pow((x_var[n] - G_t), 2);

		y_obj[0] = x_var[0];
		y_obj[1] = g * (1 - pow(y_obj[0] / g, H_t));
	}


	if (str_benchmark == "dMOP3")
	{
		/* 20171019
		double t;
		double G_t, H_t;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		G_t = sin(0.5 * pi * t);
		H_t = 0.75 * sin(0.5 * pi * t) + 1.25;

		double g = 1;
		for (int n = 0; n<nvar; n++)
			g += pow((x_var[n] - G_t), 2);

		y_obj[0] = x_var[0];
		y_obj[1] = g * (1 - pow(y_obj[0] / g, 0.5));*/
		double t;
		double G_t, H_t;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		G_t = abs(sin(0.5 * pi * t));
		H_t = 0.75 * sin(0.5 * pi * t) + 1.25;

		double g = 0;
		for (int n = 0; n < nvar; n++)
		{
			if (n == Parar) continue;
			g += pow((x_var[n] - G_t),2.0);
		}
		g = 1 + g;

		y_obj[0] = x_var[Parar];
		y_obj[1] = g*(1 - sqrt(y_obj[0]/g));

		return;

	}

	if (str_benchmark == "F5")
	{
		double t;
		double a, b, H, Gi, gx1 = 0.0, gx2 = 0.0;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		H = 1.25 + 0.75*sin(pi*t);

		t = t * 0.5;
		a = 2.0*cos(pi*t) + 2;
		b = 2.0*sin(2.0*pi*t) + 2;

		for (int i = 1; i<nvar; i++)
		{
			Gi = 1.0 - pow(abs(x_var[0] - a), H + double(i + 1.0) / double(nvar));
			if (i % 2 == 1)
				gx1 += pow(x_var[i] - b - Gi, 2.0);
			else
				gx2 += pow(x_var[i] - b - Gi, 2.0);
		}
		y_obj[0] = pow(abs(x_var[0] - a), H) + 0.5*gx1;
		y_obj[1] = pow(abs(x_var[0] - a - 1.0), H) + 0.5*gx2;
	}

	if (str_benchmark == "F6")
	{
		double t;
		double a, b, H, Gi, gx1 = 0.0, gx2 = 0.0;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		H = 1.25 + 0.75*sin(pi*t);

		t = t * 0.5;
		a = 2.0*cos(1.5*pi*t)*sin(0.5*pi*t) + 2;
		b = 2.0*cos(1.5*pi*t)*cos(0.5*pi*t) + 2;

		for (int i = 1; i<nvar; i++)
		{
			Gi = 1.0 - pow(abs(x_var[0] - a), H + double(i + 1.0) / double(nvar));
			if (i % 2 == 1)
				gx1 += pow(x_var[i] - b - Gi, 2.0);
			else
				gx2 += pow(x_var[i] - b - Gi, 2.0);
		}
		y_obj[0] = pow(abs(x_var[0] - a), H) + 0.5*gx1;
		y_obj[1] = pow(abs(x_var[0] - a - 1.0), H) + 0.5*gx2;
	}

	if (str_benchmark == "F7")
	{
		double t;
		double a, b, H, Gi, gx1 = 0.0, gx2 = 0.0;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		H = 1.25 + 0.75*sin(pi*t);

		t = t * 0.5;
		a = 1.7*(1 - sin(pi*t))*sin(pi*t) + 3.4;
		b = 1.4*(1 - sin(pi*t))*cos(pi*t) + 2.1;

		for (int i = 1; i<nvar; i++)
		{
			Gi = 1.0 - pow(abs(x_var[0] - a), H + double(i + 1.0) / double(nvar));
			if (i % 2 == 1)
				gx1 += pow(x_var[i] - b - Gi, 2.0);
			else
				gx2 += pow(x_var[i] - b - Gi, 2.0);
		}
		y_obj[0] = pow(abs(x_var[0] - a), H) + 0.5*gx1;
		y_obj[1] = pow(abs(x_var[0] - a - 1.0), H) + 0.5*gx2;
	}

	if (str_benchmark == "F8")
	{
		double t;
		double G, H;
		double g = 0;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);

		G = sin(0.5 * pi * t);
		H = 1.25 + 0.75 * sin(pi * t);

		double temp;
		for (int i = 2; i<nvar; i++)
		{
			temp = pow(0.5*(x_var[0] + x_var[1]), H + double(i + 1.0) / double(2 * nvar));
			g += (x_var[i] - temp - G)*(x_var[i] - temp - G);
		}

		y_obj[0] = (1 + g)*cos(0.5*pi*x_var[1])*cos(0.5*pi*x_var[0]);
		y_obj[1] = (1 + g)*cos(0.5*pi*x_var[1])*sin(0.5*pi*x_var[0]);
		y_obj[2] = (1 + g)*sin(0.5*pi*x_var[1]);
	}

	if (str_benchmark == "F9")
	{
		double t;
		double a, b, H, Gi, gx1 = 0.0, gx2 = 0.0;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		H = 1.25 + 0.75*sin(pi*t);
		t = t * 0.5;
		t = (t - floor(t));
		a = 2 * cos(pi*t) + 2;
		b = 2 * sin(2 * pi*t) + 2;

		for (int i = 1; i<nvar; i++)
		{
			Gi = 1.0 - pow(abs(x_var[0] - a), H + double(i + 1.0) / double(nvar));
			if (i % 2 == 1)
				gx1 += pow(x_var[i] - b - Gi, 2.0);
			else
				gx2 += pow(x_var[i] - b - Gi, 2.0);
		}
		y_obj[0] = pow(abs(x_var[0] - a), H) + 0.5*gx1;
		y_obj[1] = pow(abs(x_var[0] - a - 1.0), H) + 0.5*gx2;
	}

	if (str_benchmark == "F10")
	{
		double t;
		double a, b, H, Gi, gx1 = 0.0, gx2 = 0.0;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		bool turn = true;
		bool old = (((unsigned int)(t*10.0 + 0.001)) % 2 == 1);
		H = 1.25 + 0.75*sin(pi*t);
		t = t * 0.5;
		a = 2 * cos(pi*t) + 2;
		b = 2 * sin(2 * pi*t) + 2;

		for (int i = 1; i<nvar; i++)
		{
			if (turn && old)
				Gi = pow(abs(x_var[0] - a), H + double(i + 1.0) / double(nvar));
			else
				Gi = 1.0 - pow(abs(x_var[0] - a), H + double(i + 1.0) / double(nvar));

			if (i % 2 == 1)
				gx1 += pow(x_var[i] - b - Gi, 2.0);
			else
				gx2 += pow(x_var[i] - b - Gi, 2.0);
		}
		y_obj[0] = pow(abs(x_var[0] - a), H) + 0.5*gx1;
		y_obj[1] = pow(abs(x_var[0] - a - 1.0), H) + 0.5*gx2;
	}




	if (str_benchmark == "F8m")
	{
		double t;
		double G, H;
		double g = 0;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);

		G = sin(0.5 * pi * t);
		H = 1.25 + 0.75 * sin(pi * t);

		double temp;
		for (int i = 2; i<nvar; i++)
		{
			temp = pow(0.5*(x_var[0] + x_var[1]), H);
			g += (x_var[i] - temp - G)*(x_var[i] - temp - G);
		}

		y_obj[0] = (1 + g)*cos(0.5*pi*x_var[1])*cos(0.5*pi*x_var[0]);
		y_obj[1] = (1 + g)*cos(0.5*pi*x_var[1])*sin(0.5*pi*x_var[0]);
		y_obj[2] = (1 + g)*sin(0.5*pi*x_var[1]);
	}
	if (str_benchmark == "HE1")
	{
	}


	/***** CEC 2015 DMO Competition *****/
	if (str_benchmark == "HE2")
	{
		double t;
		double G, H;
		double g = 0;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);

		G = sin(0.5 * pi * t);
		H = 1.25 + 0.75 * sin(0.5 * pi * t);
		y_obj[0] = x_var[0];

		for (int n = 1; n<nvar; n++)
			g += x_var[n] * x_var[n];
		g = 1 + (9 / (nvar - 1))*g;

		y_obj[1] = g * (1 - pow(sqrt(y_obj[0] / g), H) - (pow(y_obj[0] / g, H)) * sin(10 * pi*y_obj[0]));
	}

	if (str_benchmark == "HE7")
	{
		double t;
		double G, H;
		double g = 0;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		G = sin(0.5 * pi * t);
		H = 1.25 + 0.75 * sin(0.5 * pi * t);

		double sum1 = 0, sum2 = 0, count1 = 0, count2 = 0;
		double temp = 0;
		for (int n = 1; n<nvar; n++)
		{
			if (n % 2 == 0) //j is even
			{
				temp = pow(x_var[n] - (0.3*pow(x_var[0], 2)*cos(24 * pi*x_var[0] + 4 * n*pi / nvar) + 0.6*x_var[0])*cos(6 * pi*x_var[0] + n*pi / nvar), 2);
				count1++;
				sum1 += temp;
			}
			else
			{
				temp = pow(x_var[n] - (0.3*pow(x_var[0], 2)*cos(24 * pi*x_var[0] + 4 * n*pi / nvar) + 0.6*x_var[0])*sin(6 * pi*x_var[0] + n*pi / nvar), 2);
				count2++;
				sum2 += temp;
			}
		}

		y_obj[0] = x_var[0] + (2 / count1)*sum1;
		g = 2 - sqrt(x_var[0]) + (2 / count2)*sum2;

		y_obj[1] = g * (1 - pow(y_obj[0] / g, H));
	}

	if (str_benchmark == "HE9")
	{
		double t;
		double G, H;
		double g = 0;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);
		G = sin(0.5 * pi * t);
		H = 1.25 + 0.75 * sin(0.5 * pi * t);

		double sum1 = 0, sum2 = 0, count1 = 0, count2 = 0;
		double temp = 0;
		for (int n = 1; n<nvar; n++)
		{
			temp = pow(x_var[n] - sin(6 * pi*x_var[0] + n*pi / nvar), 2);
			if (n % 2 == 0) //j is odd
			{
				count1++;
				sum1 += temp;
			}
			else
			{
				count2++;
				sum2 += temp;
			}
		}

		y_obj[0] = x_var[0] + (2 / count1)*sum1;
		g = 2 - pow(x_var[0], 2) + (2 / count2)*sum2;

		y_obj[1] = g * (1 - pow(y_obj[0] / g, H));
	}

	if (str_benchmark == "DIMP1")
	{
		double t;

		double G, H;
		double g = 0;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);

		y_obj[0] = x_var[0];

		for (int n = 1; n<nvar; n++)
		{
			G = sin(0.5*pi*t + 2 * pi*pow((n + 1) / (nvar + 1), 2));
			g += pow(x_var[n] - G, 2);
		}
		g += 1;

		y_obj[1] = g * (1 - pow(y_obj[0] / g,2));
	}

	if (str_benchmark == "DIMP2")
	{
		double t;
		double G, H;
		double g = 0;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);

		y_obj[0] = x_var[0];

		for (int n = 1; n<nvar; n++)
		{
			G = sin(0.5*pi*t + 2 * pi*pow((n + 1) / (nvar + 1), 2));
			g += pow(x_var[n] - G, 2) - 2 * cos(3 * pi*(x_var[n] - G));
		}
		g += 1 + 2 * (nvar - 1);
		y_obj[1] = g * (1 - sqrt(y_obj[0] / g));
	}

	if (str_benchmark == "JY1") //JY1
	{
		unsigned int j, count1, count2;
		double a, w, g, sum1;
		double t;
		t = 1.0 / n_t*floor(1.0*tau / tau_t);

		a = 0.05, w = 6;
		g = sin(0.5*pi*t);
		sum1 = 0;
		for (j = 1; j < nvar; j++)
		{
			double x = x_var[j];
			double yj = x - g;
			yj = yj*yj;
			sum1 += yj;
		}
		y_obj[0] = (1 + sum1)*(x_var[0] + a*sin(w*pi*x_var[0]));
		y_obj[1] = (1 + sum1)*(1 - x_var[0] + a*sin(w*pi*x_var[0]));
		return;
	}
}

#endif
