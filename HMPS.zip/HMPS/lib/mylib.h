#ifndef __MYLIB_H_
#define __MYLIB_H_

using namespace std;
void minfastsort(double x[], int idx[], int n, int m)
{
	for (int i = 0; i<m; i++)
	{
		for (int j = i + 1; j<n; j++)
			if (x[i]>x[j])
			{
				double temp = x[i];
				x[i] = x[j];
				x[j] = temp;
				int id = idx[i];
				idx[i] = idx[j];
				idx[j] = id;
			}
	}
}

double dist_array(double vec1[], double vec2[], int dim)
{
	double sum = 0;
	for (int n = 0; n<dim; n++)
		sum += (vec1[n] - vec2[n])*(vec1[n] - vec2[n]);
	return sqrt(sum);
}

double dist_vector(vector <double> &vec1, vector <double> &vec2)
{
	int dim = vec1.size();
	double sum = 0;
	for (int n = 0; n<dim; n++)
		sum += (vec1[n] - vec2[n])*(vec1[n] - vec2[n]);
	return sqrt(sum);
}

double sqrd_dist_vector(vector <double> &vec1, vector <double> &vec2)
{
	int dim = vec1.size();
	double sum = 0;
	for (int n = 0; n<dim; n++)
		sum += (vec1[n] - vec2[n])*(vec1[n] - vec2[n]);
	return sum;
}

double dist_p(vector <double> &vec1, vector <double> &vec2, int p)
{
	int dim = vec1.size();
	double sum = 0;
	for (int n = 0; n<dim; n++)
		sum += pow(vec1[n] - vec2[n], 2);
	sum = pow(sqrt(sum), p);
	return sum;
}

double norm_vector(vector <double> &vec)
{
	int    dim = vec.size();
	double sum = 0;
	for (int i = 0; i<dim; i++)
		sum = sum + vec[i] * vec[i];
	return sqrt(sum);
}



double sum_vector(vector<double>&vec)
{
	int dim = vec.size();
	double sum = 0;
	for (int i = 0; i<dim; i++)
		sum = sum + vec[i];
	return sum;
}

// inner product
double prod_vector(vector <double>&vec1, vector <double>&vec2)
{
	int dim = vec1.size();
	double sum = 0;
	for (int i = 0; i<dim; i++)
		sum += vec1[i] * vec2[i];
	return sum;
}


double rnd_gaussian(long *idum, double mean, double stddev)
{
	double  q, u, v, x, y;

	/*
	Generate P = (u,v) uniform in rect. enclosing acceptance region
	Make sure that any random numbers <= 0 are rejected, since
	gaussian() requires uniforms > 0, but RandomUniform() delivers >= 0.
	*/
	do {
		u = rnd_uni(idum);
		v = rnd_uni(idum);
		if (u <= 0.0 || v <= 0.0) {
			u = 1.0;
			v = 1.0;
		}
		v = 1.7156 * (v - 0.5);

		/*  Evaluate the quadratic form */
		x = u - 0.449871;
		y = fabs(v) + 0.386595;
		q = x * x + y * (0.19600 * y - 0.25472 * x);

		/* Accept P if inside inner ellipse */
		if (q < 0.27597)
			break;

		/*  Reject P if outside outer ellipse, or outside acceptance region */
	} while ((q > 0.27846) || (v * v > -4.0 * log(u) * u * u));

	/*  Return ratio of P's coordinates as the normal deviate */
	return (mean + stddev * v / u);
}


#endif
