#ifndef _MATRIX_H_
#define _MATRIX_H_

// preprocessor directive
#include <vector>

using namespace std;

// VECTOR OPERATOR OVERLOADING

// vector add with vector	------ vec-Add-vec-001
vector< double > operator+(vector< double > left, vector< double > right)
{
	if (left.size() == right.size())
	{
		vector< double > result;
		for (int i = 0; i < left.size(); i++)
			result.push_back(left[i] + right[i]);
		return result;
	} // end if
	else
		throw "vec-Add-vec-001: size of vectors not equal.";
} // end function operator+

  // vector subtract with vector	------ vec-Sub-vec-002 
vector< double > operator-(vector< double > left, vector< double > right)
{
	if (left.size() == right.size())
	{
		vector< double > result;
		for (int i = 0; i < left.size(); i++)
			result.push_back(left[i] - right[i]);
		return result;
	} // end if
	else
		throw "vec-Add-vec-002: size of vectors not equal.";
} // end function operator-

  // vector divide with a scalar
vector< double > operator/(vector< double > left, double denominator)
{
	for (int i = 0; i < left.size(); i++)
		left[i] = left[i] / denominator;
	return left;
} // end function operator/

  // vector multiply with a scalar
vector< double > operator*(double left, vector< double > right)
{
	for (int i = 0; i < right.size(); i++)
		right[i] *= left;
	return right;
} // end function operator*

  // MATRIX OPERATOR OVERLOADING

  // matrix multiply with a scalar
vector< vector< double > > operator* (double left, vector< vector< double > > right)
{
	for (int i = 0; i < right.size(); i++)
		for (int j = 0; j < right[i].size(); j++)
			right[i][j] *= left;
	return right;
} // end function operator*

  // matrix add with matrix	------ mat-Add-mat-003 
vector< vector< double > > operator+(vector< vector< double > > left, vector< vector< double > > right)
{
	if ((left.size() == right.size()) && (left.at(0).size() == right.at(0).size()))
	{
		for (int i = 0; i < left.size(); i++)
			for (int j = 0; j < left[i].size(); j++)
				left[i][j] += right[i][j];
		return left;
	} // end if
	else
		throw "vec-Add-vec-003: size of vectors not equal.";
} // end function operator+

  // VECTOR OPERATOR

  // vector product	------ vec-Tim-vec-004 
vector< vector< double > > operator*(vector< double > left, vector< double > right)
{
	if (left.size() == right.size())
	{
		vector< vector< double > > result;
		for (int i = 0; i < left.size(); i++)
			result.push_back(right[i] * left);
		return result;
	} // end if
	else
		throw "vec-Add-vec-004: size of vectors not equal.";
} // end function operator*

  // scalar product - vector dot vector	------ vec-Dot-vec-005
double dot(vector< double > left, vector< double > right)
{
	if (left.size() == right.size())
	{
		double result = 0;
		for (int i = 0; i < left.size(); i++)
			result += left[i] * right[i];
		return result;
	} // end if
	else
		throw "vec-Add-vec-005: size of vectors not equal.";
} // end function operator*

  // scalar product - vector dot matrix
vector< double > dot(vector< double > left, vector< vector< double > > right)
{
	if (left.size() == right.size())
	{
		vector< double > result(right.at(0).size(), 0.0);
		for (int i = 0; i < right.at(0).size(); i++)
			for (int j = 0; j < right.size(); j++)
				result[i] += left[j] * right[j][i];
		return result;
	}
	else
		throw "vec-Add-vec-006: size of vectors not equal.";
} // end function operator*
vector<double> dot(vector<vector<double>> left, vector<double> right)
{
	//cout<<"left.at(0).size:"<<left.at(0).size()<<" right.size():"<<right.size()<<endl;
	if (left.at(0).size() == right.size())
	{
		//cout<<"Hi"<<endl;
		vector< double > result;
		result.resize(left.size(), 0.0);
		//cout<<"after result initialization"<<endl;
		for (int i = 0; i<left.size(); i++)
			for (int j = 0; j<left.at(0).size(); j++)
			{
				//cout<<i<<j<<"in loop"<<endl;
				result[i] += left[i][j] * right[j];
			}
		return result;
		//cout<<"End Hi"<<endl;
	}
	else
		throw "vec-Add-vec-006: size of vectors not equal.";
}
// Dominance relationship
bool operator>(vector< double > left, vector< double > right)
{
	if (left.size() == right.size())
	{
		bool result = true;
		for (int i = 0; i < left.size(); i++)
			if (left[i] < right[i])
				return false;
		return result;
	} // end if
	else
		throw "Function Operator> : Vectors size not equal.";
} // end function operator>

bool operator<(vector< double > left, vector< double > right)
{
	if (left.size() == right.size())
	{
		bool result = true;
		for (int i = 0; i < left.size(); i++)
			if (left[i] > right[i])
				return false;
		return result;
	} // end if
	else
		throw "Function Operator> : Vectors size not equal.";
} // end function operator>

  // scalar product - matrix dot matrix
vector<vector< double >> dot(vector<vector< double >> left, vector< vector< double > > right)
{
	if (left.at(0).size() == right.size())
	{
		vector<vector< double >> result;
		result.resize(left.size(), vector<double>(right.at(0).size(), 0));
		for (int i = 0; i<left.size(); i++)
			result.at(i) = dot(left.at(i), right);
		return result;
	}
	else
		throw "vec-Dot-vec-007: size of vectors not match.";
}

//transpose of matrix
vector<vector<double>> transpose(vector<vector<double>> matrix)
{
	vector<vector<double>> result;
	result.resize(matrix.at(0).size(), vector<double>(matrix.size()));
	for (int i = 0; i<matrix.size(); i++)
		for (int j = 0; j<matrix.at(0).size(); j++)
			result.at(j).at(i) = matrix.at(i).at(j);
	return result;
}

// matrix minus with matrix	------ mat-minus-mat-008
vector< vector< double > > operator-(vector< vector< double > > left, vector< vector< double > > right)
{
	if ((left.size() == right.size()) && (left.at(0).size() == right.at(0).size()))
	{
		for (int i = 0; i < left.size(); i++)
			for (int j = 0; j < left[i].size(); j++)
				left[i][j] -= right[i][j];
		return left;
	} // end if
	else
		throw "mat-Minus-mat-008: size of vectors not equal.";
} // end function operator+

  //identity/unit matrix of size-by-size
vector<vector<double>> identitym(int size)
{
	if (size >= 1)
	{
		vector<vector<double>> result;
		result.resize(size, vector<double>(size));
		for (int i = 0; i< size; i++)
			for (int j = 0; j<size; j++)
			{
				if (i == j)
					result.at(i).at(j) = 1;
				else
					result.at(i).at(j) = 0;
			}
		return result;
	}
	else
		throw "mat-Minus-mat-009: size of matrix less than 1.";
}

// inverse matrix
vector< vector< double > > invMat(vector< vector< double > > matrix)
{
	// Matrix inverse using Gauss Jordan elimination
	// Create identity matrix
	int dimension = matrix.size();
	vector< double > zero(dimension, 0.0);
	vector< vector< double > > inverse(dimension, zero);
	for (int i = 0; i < dimension; i++)
		inverse[i][i] = 1.0;

	for (int k = 0; k<dimension; k++)
	{
		double val = 1.0 / matrix[k][k];
		for (int i = k; i<dimension; i++)
			matrix[k][i] *= val;
		for (int i = 0; i<dimension; i++)
			inverse[k][i] *= val;

		for (int i = 0; i<dimension; i++)
		{
			if (i != k)
			{
				double temp = matrix[i][k];
				for (int j = 0; j<dimension; j++)
					matrix[i][j] -= temp*matrix[k][j];
				for (int j = 0; j<dimension; j++)
					inverse[i][j] -= temp*inverse[k][j];
			}
		}
	}

	return inverse;
} // end function invMat
#endif
